package com.lanchenlayer;

import com.lanchenlayer.applications.ProdutoApplication;
import com.lanchenlayer.entities.Estado;
import com.lanchenlayer.facade.ProdutoFacade;
import com.lanchenlayer.repositories.ProdutoRepository;
import com.lanchenlayer.services.ProdutoService;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 * Hello world!
 */
public class Console {
    private static ProdutoRepository produtoRepository;
    private static ProdutoService produtoService;
    private static ProdutoApplication produtoApplication;
    private static ProdutoFacade produtoFacade;
    private static Scanner scanner;

    public static void resolverDependencias() {
        produtoRepository = new ProdutoRepository();
        produtoService = new ProdutoService();
        produtoApplication = new ProdutoApplication(produtoRepository, produtoService);
        produtoFacade = new ProdutoFacade(produtoApplication);
        scanner = new Scanner(System.in);
    }

    public static void inicializar(){
        produtoFacade.adicionar(new Estado(1,75, "Bahia - BA" ,"CC:\\Users\\dejes\\Downloads\\LancheNLayer\\src\\main\\resources\\images\\ImagensEstados"));
        produtoFacade.adicionar(new Estado(2,23, "Espírito Santo - ES", "C:\\Users\\dejes\\Downloads\\LancheNLayer\\src\\main\\resources\\images\\ImagensEstados"));
    }

    public static void listarEstado() {
        System.out.println("  ID  |  DDD  |       NOME      |       IMAGEM      ");

        ArrayList<Estado> estados = produtoFacade.buscarTodosEstados();

        estados.forEach(c -> {
            System.out.println(c.getId()+" | "+c.getDdd()+" |     " +c.getNome() + "   |     " + c.getImagem());
        });
    }

    public static void buscarPorDdd() {
        System.out.print("Informe o DDD: ");
        int ddd = scanner.nextInt();

        ArrayList<Estado> estados = produtoFacade.buscarTodosEstados();

        ArrayList<Estado> estadoFiltrado = (ArrayList<Estado>) estados.stream().filter(estado -> estado.getDdd() == ddd).collect(Collectors.toList());

        // Exibe o resultado
        if (estadoFiltrado.isEmpty()) {
            System.out.println("Nenhum estado encontrado com o DDD: " + ddd);
        } else {
            System.out.println("Estados encontrados com o DDD " + ddd + ":");
            estadoFiltrado.forEach(estado -> System.out.println(estado.getNome()));
        }
    }




    public static void cadastrarEstado() {

        System.out.println("Informe o ID do Estado: ");
        int id = scanner.nextInt();

        System.out.println("Informe o DDD do Estado: ");
        int ddd = scanner.nextInt();

        System.out.println("Informe o nome do estado: ");
        String nome = scanner.next();

        System.out.println("Informe o caminho da imagem do estado: ");
        String imagem = scanner.next();

        Estado estado = new Estado(id, ddd, nome, imagem);
        produtoFacade.adicionar(estado);
    }

    public static void exibirMenu() {
        System.out.println("1 - Novo Estado");
        System.out.println("2 - Atualizar Estado");
        System.out.println("3 - Listar Estado");
        System.out.println("4 - Buscar por DDD Estado");
        System.out.println("5 - Remover Estado");
        System.out.println("6 - Sair");
    }

    public static int solicitarInputUsuario() {
        System.out.println("Informe a opção do menu desejado: ");
        return scanner.nextInt();
    }

    private static void atualizarEstado() {
        System.out.println("Informe o ID do Estado que deseja atualizar: ");
        int id = scanner.nextInt();

        System.out.println("Informe a novo DDD do estado: ");
        int ddd = scanner.nextInt();

        System.out.println("Informe o novo nome do estado: ");
        String nome = scanner.nextLine();
        scanner.next();

        System.out.println("Informe o novo caminho da imagem do estado: ");
        String imagem = scanner.nextLine();
        scanner.next();

        Estado estado = new Estado(id, ddd, nome, imagem);
        produtoFacade.atualizarEstado(id, estado);
    }

    public static void removerEstado() {
        System.out.println("Informe o ID do Estado que deseja remover: ");
        int id = scanner.nextInt();
        produtoFacade.removerEstado(id);
    }

    public static void rodar() {
        int opcaoMenu = 0;

        do {
            exibirMenu();
            opcaoMenu = solicitarInputUsuario();
            switch (opcaoMenu) {
                case 1:
                    cadastrarEstado();
                    break;
                case 2:
                    atualizarEstado();
                    break;
                case 3:
                    listarEstado();
                    break;
                case 4:
                    buscarPorDdd();
                    break;
                case 5:
                    removerEstado();
                    break;
            }

        } while (opcaoMenu != 6);
    }

    public static void main(String[] args) {
        resolverDependencias();
        inicializar();
        rodar();
    }
}
