package com.lanchenlayer.applications;

import com.lanchenlayer.entities.Estado;
import com.lanchenlayer.repositories.ProdutoRepository;
import com.lanchenlayer.services.ProdutoService;

import java.util.ArrayList;

public class ProdutoApplication {

    private ProdutoRepository produtoRepository;
    private ProdutoService produtoService;

    public ProdutoApplication(ProdutoRepository produtoRepository, ProdutoService produtoService) {
        this.produtoRepository = produtoRepository;
        this.produtoService = produtoService;
    }

    public void adicionarEstado(Estado estado){
        this.produtoRepository.adicionarEstado(estado);
        this.produtoService.salvarImagemEstado(estado);
    }

    public void adicionarSoImagemEstado(Estado estado) {
        this.produtoService.salvarImagemEstado(estado);
    }

    public void removerEstado(int id) {
        this.produtoRepository.removerEstado(id);
        this.produtoService.removerImagemEstado(id);
    }

    public Estado buscarPorId(int id) {
        return this.produtoRepository.buscarPorId(id);
    }

        public Estado buscarPorDdd(int ddd) {
        return this.produtoRepository.buscarPorDdd(ddd);
    }

    public ArrayList<Estado> buscarTodosEstados() {
        return this.produtoRepository.buscarTodosEstados();
    }

    public void atualizarEstado(int id, Estado estado) {
        this.produtoRepository.atualizarEstado(id, estado);
        this.produtoService.atualizarImagemEstado(estado);
    }

}
