package com.lanchenlayer.entities;

public class Estado {

    private int id;
    private int ddd;
    private String nome;
    private String imagem;

    public Estado(int id, int ddd, String nome, String imagem) {
        this.id = id;
        this.ddd = ddd;
        this.nome = nome;
        this.imagem = imagem;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDdd() {
        return ddd;
    }

    public void setDdd(int ddd) {
        this.ddd = ddd;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    @Override
    public String toString() {
        return "Estado:" + "\nddd=" + ddd + "\nnome='" + nome + "\nimagem=" + imagem;
    }

}
