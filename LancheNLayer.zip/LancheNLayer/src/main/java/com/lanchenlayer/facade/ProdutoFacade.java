package com.lanchenlayer.facade;

import com.lanchenlayer.applications.ProdutoApplication;
import com.lanchenlayer.entities.Estado;

import java.util.ArrayList;

public class ProdutoFacade {
    private ProdutoApplication produtoApplication;

    public ProdutoFacade(ProdutoApplication produtoApplication) {
        this.produtoApplication = produtoApplication;
    }

    public void adicionar(Estado estado) {
        this.produtoApplication.adicionarEstado(estado);
    }

    public void removerEstado(int id) {
        this.produtoApplication.removerEstado(id);
        this.produtoApplication.buscarPorId(id);}

    public Estado buscarPorDdd(int ddd) {
        return this.produtoApplication.buscarPorDdd(ddd);
    }

    public ArrayList<Estado> buscarTodosEstados() {
        return this.produtoApplication.buscarTodosEstados();
    }

    public void atualizarEstado(int id, Estado estado) {
        this.produtoApplication.atualizarEstado(id, estado);
    }
}
