package com.lanchenlayer.repositories;

import com.lanchenlayer.entities.Estado;

import java.util.ArrayList;

public class ProdutoRepository {


    private ArrayList<Estado> estados = new ArrayList<Estado>();

    public void adicionarEstado(Estado estado){estados.add(estado);}

    public boolean removerEstado(int id) {return estados.removeIf(e -> e.getId() == id);}

    private Estado filtrarEstado(int ddd){return estados.stream().filter(e -> e.getDdd() == ddd).findFirst().get();}


    public Estado buscarPorId(int id) {
        Estado estadoInDb = filtrarEstado(id);
        return estadoInDb;
    }
    public Estado buscarPorDdd(int ddd){
        Estado estadoInDb = filtrarEstado(ddd);
        return estadoInDb;}

    public ArrayList<Estado> buscarTodosEstados(){
        return estados;
    }


    public void atualizarEstado(int ddd, Estado estado){
        Estado estadInDb = filtrarEstado(ddd);

        estadInDb.setDdd(estado.getDdd());
        estadInDb.setNome(estado.getNome());
        estadInDb.setImagem(estado.getImagem());
    }

}
