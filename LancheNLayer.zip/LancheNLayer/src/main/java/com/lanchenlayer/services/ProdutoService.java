package com.lanchenlayer.services;

import com.lanchenlayer.entities.Estado;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

public class ProdutoService {

    private String caminhoDestinoEstado = "C:\\Users\\aluno\\LancheNLayer\\src\\main\\resources\\images\\ImagensEstados";


    public static String getFileExtension(String filePath) {
        String fileName = new File(filePath).getName();
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex == -1) ? "No extension" : fileName.substring(dotIndex + 1);
    }

    public boolean salvarImagemEstado(Estado estado) {
        Path path = Paths.get(estado.getImagem());

        Path pastaDestinoEstado = Paths.get(String.format("%s%d.%s", caminhoDestinoEstado, estado.getDdd(), getFileExtension(estado.getImagem())));

        if (Files.exists(path)) {
            try {
                Files.copy(path, pastaDestinoEstado, StandardCopyOption.REPLACE_EXISTING);
                estado.setImagem(pastaDestinoEstado.getFileName().toString());
                return true;
            } catch (Exception ex) {
                return false;
            }
        }

        return false;
    }


    private String buscarCaminhoArquivoPorId(int id) {
        File diretorio = new File(caminhoDestinoEstado);
        File[] matches = diretorio.listFiles(new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return name.startsWith(String.valueOf(id));
            }
        });
        return Arrays.stream(matches).findFirst().get().getAbsolutePath();
    }

    public void removerImagemEstado(int ddd) {
        Path path = Paths.get(buscarCaminhoArquivoPorId(ddd));
        try {
            Files.deleteIfExists(path);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void atualizarImagemEstado(Estado estado) {
        removerImagemEstado(estado.getDdd());
        salvarImagemEstado(estado);
    }
}
